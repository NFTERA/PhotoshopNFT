PASSWORD: psplugin

Installation:
1) Close Photoshop
2) Run plugin installer and install .js script
3) Run Photoshop and select script in context menu
4) Enjoy
